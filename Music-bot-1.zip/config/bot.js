module.exports = {
    emojis: {
        off: ':x:',
        error: ':warning:',
        queue: ':bar_chart:',
        music: ':musical_note:',
        success: ':white_check_mark:',
    },

    discord: {
        token: 'ODA0NjIyMjUxMTQ4MzEyNTg2.YBPA3Q.NHvo4d5DvzgyJUgjw_b-Gi2Z__M',
        prefix: 'A=',
        activity: 'A=help/Bot created by |✓|ANTOR#8129|🎧|',
    },

    filters: ['8D', 'gate', 'haas', 'phaser', 'treble', 'tremolo', 'vibrato', 'reverse', 'karaoke', 'flanger', 'mcompand', 'pulsator', 'subboost', 'bassboost', 'vaporwave', 'nightcore', 'normalizer', 'surrounding'],
};