module.exports = (client, message, track) => {
    message.channel.send(`${client.emotes.music} - <a:MusicBeat:837526781941514240>Now playing ${track.title} into ${message.member.voice.channel.name} ...`);
    message.delete()
    
};